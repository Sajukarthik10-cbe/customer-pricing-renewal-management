# Customer Pricing & Renewal Management System

## Project Overview
A portfolio project simulating a customer-pricing operations workflow for a global organization.

**Business flow:**
Sales request → Data validation → Pricing-policy validation → ERP-ready condition → Renewal tracking → Operational reporting.

> This is a portfolio simulation. It does not claim real SAP/ERP production experience.

## Business Problem
Sales teams need customer prices created or renewed on time. Pricing operations must validate customer/product data, pricing limits, effective dates and expiry dates before a condition is approved.

## Tools
- Excel: operational data review, Pivot-ready datasets and reporting
- SQL Server: data storage, joins, validation and operational reports
- Python/Pandas: automated data-quality checks
- Power BI: KPI and renewal dashboards

## Data Model
Customers and Products are master tables. Pricing Conditions store customer-product prices and validity dates. Pricing Requests represent incoming Sales Team requests.

## Key Validations
1. Customer ID exists
2. Product ID exists
3. Customer price is populated
4. Discount does not exceed policy limit
5. Effective date is before expiry date
6. Renewal bucket identifies expired and soon-to-expire conditions

## Power BI Dashboard Suggestions
### Page 1 — Pricing Overview
- Total customers
- Active pricing conditions
- Pending requests
- Expired conditions
- Policy exceptions

### Page 2 — Renewal Tracker
- Customer
- Product
- Current price
- Expiry date
- Renewal bucket
- Account manager

### Page 3 — Pricing Analysis
- Customer segment
- Industry
- Product category
- Average customer price
- Discount analysis
- Price-change analysis

## How to Run

### Python
```bash
cd python
python pricing_validation.py
```

### SQL
1. Create a SQL Server database.
2. Run `sql/create_tables.sql`.
3. Import the CSV files from `data/`.
4. Run `sql/pricing_reports.sql`.

### Excel
Open `excel/customer_pricing_operations.xlsx` for operational review.

### Power BI
Use `powerbi/pricing_powerbi_ready.csv` as a starting dataset. Create relationships to the master tables if you import the individual CSVs instead.

## Example Business Scenario
A Sales Representative requests a renewal for a customer-product combination. The requested discount is compared with the customer's permitted pricing policy. Valid requests can proceed to the ERP pricing workflow; exceptions are returned for review.

## Resume Relevance
This project demonstrates:
- Advanced Excel
- SQL reporting
- Data validation
- Pricing and renewal workflow concepts
- Power BI reporting
- Python automation
- Business stakeholder requirements
- Time-sensitive operational reporting

## Important
The project demonstrates an ERP-style pricing process. It should not be presented as hands-on SAP experience unless the candidate has actually used SAP.
